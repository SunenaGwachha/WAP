package cs472.mum;

import org.omg.CORBA.Request;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import static java.lang.Integer.parseInt;

public class advancedCalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String number1 = "";
        String number2 = "";
        String number3 = "";
        String number4 = "";
        String result1 = "";
        String result2 = "";





if(request!=null) {

    number1 = request.getParameter("number1");
    number2 = request.getParameter("number2");
    number3 = request.getParameter("number3");
    number4 = request.getParameter("number4");

    result1=Integer.toString(parseInt(number1)+ parseInt(number2));
    result2=Integer.toString(parseInt(number3)* parseInt(number4));

}

    PrintWriter out = response.getWriter();


        out.print("<html><head><title>Test</title></head><body>");
        out.print("<form method=\"post\" action=\"hello1\">\n" +
                "Advanced Calculater <br><br>\n" +
                "      Addition :<br>\n" +
                "      <input type=\"text\" name=\"number1\" value="+  number1   +"> +\n" +
                "      <input type=\"text\" name=\"number2\" value="+number2+"> = <input type=\"text\" name=\"output1\" value="+result1+">\n" +
                "      <br>\n" +
                "      Multiplication :<br>\n" +
                "      <input type=\"text\" name=\"number3\" value="+number3+"> *\n" +
                "      <input type=\"text\" name=\"number4\" value="+number4+"> = <input type=\"text\" name=\"output2\" value="+result2+" >\n" +
                "\n" +
                "      <br><br>\n" +
                "      <input type=\"submit\" value=\"Submit\">\n" +
                "\n" +
                "        </form>");

        out.print("</body></html>");


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

       doPost(null,response);
    }
}
