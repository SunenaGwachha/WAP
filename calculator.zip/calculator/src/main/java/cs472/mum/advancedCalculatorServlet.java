package cs472.mum;

import org.omg.CORBA.Request;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import static java.lang.Integer.parseInt;

public class advancedCalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String number1 = request.getParameter("number1");
        String number2 = request.getParameter("number2");
        String number3 = request.getParameter("number3");
        String number4 = request.getParameter("number4");

        //  System.out.println("number1: " + number1);
        //  System.out.println("number2: " + number2);

        //request.setAttribute("output1", (parseInt(number1)+ parseInt(number2)));
       // request.setAttribute("output2", (parseInt(number3)+ parseInt(number4)));
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       // out.print(number1 + "+" + number2 + "=" + (parseInt(number1)+ parseInt(number2))+"\n");
       // out.print(number3 + "*" + number4 + "=" + (parseInt(number3) * parseInt(number4)));


        RequestDispatcher disp=null;
        request.setAttribute("output1", (parseInt(number1)+ parseInt(number2)));
        request.setAttribute("output2", (parseInt(number3)+ parseInt(number4)));
        disp =request.getRequestDispatcher("/index.jsp");
        disp.forward(request,response);



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
