package quizmodel;

import java.util.ArrayList;

public class Quiz {
    private int correctAns;
    private int questionCounter;
    private ArrayList<String> questions;
    private ArrayList<String> answer;

    public Quiz(){
        this.questionCounter=0;
        this.correctAns=0;
        this.questions=new ArrayList<>();
        this.answer=new ArrayList<>();

        this.questions.add("[1,2,3,?]");
        this.answer.add("4");

        this.questions.add("[0,2,4,?]");
        this.answer.add("6");

        this.questions.add("[1,3,5,?]");
        this.answer.add("7");

        this.questions.add("[3,6,9,?]");
        this.answer.add("12");

        this.questions.add("[4,8,?]");
        this.answer.add("12");


    }

    public int getNumQuestions(){
        return questions.size();
    }
    public boolean isCorrect(String arg) {
        return answer.get(0)==arg;
    }
    public int getNumCorrect(){
        return correctAns;
    }
    public void inc(){
        this.correctAns++;
    }

    public int getQuestionCounter() {
        return questionCounter;
    }

    public void setQuestionCounter(int questionCounter) {
        this.questionCounter = questionCounter;
    }


    public void setQuestions(ArrayList<String> questions) {
        this.questions = questions;
    }

    public ArrayList<String> getQuestions() {
        return questions;
    }


    public void setAnswer(ArrayList<String> answer) {
        this.answer = answer;
    }

    public ArrayList<String> getAnswer() {
        return answer;
    }


    public void decrementQuestionCounter() {
        questionCounter--;
    }

    public void incrementQuestionCounter() {
        questionCounter++;
    }

    public void decrementCorrectAns() {
        correctAns--;
    }

    public void incrementCorrectAns() {
        correctAns++;
    }

}

