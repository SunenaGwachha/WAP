
    
    function addToCart(evt, name, price, icon) {
        let left = evt.clientX + "px";
        let top = (evt.clientY - 80) + "px";

        $('#addedToCartMessagePop').css("left", left).css("top", top).fadeIn(200).fadeOut(800);

        $.ajax("cart.ajax", {
            "type": "post",
            "data": {
                "name": name,
                "price": price,
                "icon": icon
            }
        }).done(displayCartList);
    }


    function displayCartList(data) {


        let cartTable = "<table class='table table-hover' style='table-layout: fixed; width: 100%;'>" +
            "<tr><th>Pic</th></th><th>Title</th><th>Unit Price</th></tr>";

        let total = 0;
        for (let key of data) {
            total += key.price;
            let iconpic = key.icon.split(" ").join("%20");
            cartTable += "<tr><td>" + "<img src=resources/images/" + iconpic + " width='30' height='30' />" + "</td>"
                + "<td>" + key.name + "</td>" +
                "<td>$" + key.price + "</td></tr>";
        }


        if (total === 0) {
            cartTable += " <tr id=\"messageToaddToCart\"><td colspan=\"3\">Please Add Items Thanks!!!</td></tr>";


        } else {
            cartTable += "<tr><td>Total: </td><td>$" + total + "</td><td></td></tr>" +
                "<tr><td></td><td colspan='2'>" +
                "<button onclick='showThankYou()'>Check Out</button>\n" +
                "</td></tr>";

        }
        cartTable += "</table><br />";

        $("#cartlist").html(cartTable);

    }


    function showThankYou() {
        $('#thankyoumessage').fadeIn(3000).fadeOut(3000);
        $('#cartlist').hide();

        $.ajax("checkout", {
            "type": "get"
        }).done(displayCartList);
    }


    $('#showCart').click(function (evt) {
        evt.preventDefault();
        $('#cartlist').toggle();

    });


    $("#showlogin").click(function () {
        $("#id01").show();
    });
    $(".closebtn").click(function () {
        $("#errormessage").hide();

    });


    $('#addNewProduct').click(function (evt) {
        evt.preventDefault();
        $('#id01').show();
    });


    function removeIt(productId) {
        if (confirm("Are You Sure to Delete?") === true) {
            let pid = $(event.target).val();
            let rowId = '#row' + pid;

            $(rowId).hide();
            $.ajax("deleteProduct", {
                "type": "post",
                "data": {
                    "productId": productId
                }
            }).done();
        }
    }

